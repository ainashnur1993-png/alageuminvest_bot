export default async function handler(req, res) {
  try {
    if (req.method !== 'POST') return res.status(200).send('OK');

    const body = req.body;
    const message = body.message || body;
    const text = message?.text;
    if (!text) return res.status(200).send('no text');

    const SYSTEM_PROMPT = `Ты — ИИ-бот для анализа тендеров для Alageum и ЭлМО.
Фильтруй тендеры: энергетика, трансформаторы, ЛЭП, подстанции, оборудование, кабели, СМР, проектирование, машиностроение, сервис.
Игнорируй: клининг, канцтовары, продукты, медицина, IT, HR.
Всегда отвечай: "Подходит / Не подходит / Частично подходит" + краткое объяснение.`;

    const openaiResp = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${process.env.OPENAI_API_KEY}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        model: 'gpt-4o-mini',
        messages: [
          { role: 'system', content: SYSTEM_PROMPT },
          { role: 'user', content: text }
        ],
        max_tokens: 400
      })
    });

    const openaiData = await openaiResp.json();
    const reply = openaiData?.choices?.[0]?.message?.content ?? 'Не удалось получить ответ';

    const chatId = message.chat?.id;
    if (chatId) {
      await fetch(`https://api.telegram.org/bot${process.env.TELEGRAM_TOKEN}/sendMessage`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ chat_id: chatId, text: reply })
      });
    }

    return res.status(200).send('ok');
  } catch (err) {
    console.error(err);
    return res.status(500).send('error');
  }
}
